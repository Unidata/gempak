#
# Configuration file for using the XML library in GNOME applications
#
XML2_LIBDIR="-L/home/mjames/GEMPAK7/os/linux64/lib"
XML2_LIBS="-lxml2 -L/home/mjames/GEMPAK7/os/linux64/lib -lz   -lm "
XML2_INCLUDEDIR="-I/home/mjames/GEMPAK7/os/linux64/include/libxml2"
MODULE_VERSION="xml2-2.9.1"

