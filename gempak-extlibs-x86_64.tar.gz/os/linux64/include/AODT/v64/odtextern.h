/* external application functions defined in odtext directory */
extern int extern_readsstvalue(char *,float,float,int *);
extern void extern_qmessage(int,int,char *,char *);  /* XXX */
