/* external application functions defined in odtext directory */
extern int extern_readsstvalue(char *,float,float,float *);
extern int extern_readtopovalue(char *,float,float,int *);
extern void extern_qmessage(int,int,char *,char *);
extern int extern_writegrid(char *,int,float ***,int,int,int,int,float *);
